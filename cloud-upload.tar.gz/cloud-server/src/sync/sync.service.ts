import { Injectable, Logger } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { SyncPushDto, SyncPullDto } from './dto/sync-payload.dto';

@Injectable()
export class SyncService {
    private readonly logger = new Logger(SyncService.name);

    constructor(private dataSource: DataSource) { }

    async push(payload: SyncPushDto) {
        const { restaurantId, tables } = payload;
        this.logger.log(`Push received for restaurant: ${restaurantId}`);

        const queryRunner = this.dataSource.createQueryRunner();
        await queryRunner.connect();
        await queryRunner.startTransaction();

        try {
            for (const [tableName, rows] of Object.entries(tables)) {
                if (!this.isValidTable(tableName)) continue;

                for (const row of rows) {
                    // Ensure row belongs to the restaurant
                    row.restaurant_id = restaurantId;
                    // Format date fields if necessary (Postgres handles ISO strings well)

                    // Generate UPSERT query
                    const keys = Object.keys(row);
                    const values = Object.values(row);

                    if (keys.length === 0) continue;

                    // $1, $2, ... placeholders
                    const placeholders = keys.map((_, i) => `$${i + 1}`).join(', ');
                    const setClause = keys.map((k, i) => `${k} = EXCLUDED.${k}`).join(', ');

                    const sql = `
            INSERT INTO "${tableName}" (${keys.join(', ')}) 
            VALUES (${placeholders}) 
            ON CONFLICT (id) DO UPDATE SET ${setClause};
          `;

                    await queryRunner.query(sql, values);
                }
            }

            await queryRunner.commitTransaction();
            return { success: true, message: 'Sync successful' };

        } catch (err) {
            this.logger.error('Sync failed', err);
            await queryRunner.rollbackTransaction();
            throw err;
        } finally {
            await queryRunner.release();
        }
    }

    async pull(query: SyncPullDto) {
        const { restaurantId, lastSyncTime } = query;
        const result = {};

        const tables = ['users', 'products', 'categories', 'tables', 'halls', 'sales', 'sale_items', 'customers'];

        for (const table of tables) {
            const sql = `
        SELECT * FROM "${table}" 
        WHERE restaurant_id = $1 
        AND updated_at > $2
      `;
            const rows = await this.dataSource.query(sql, [restaurantId, lastSyncTime]);
            if (rows.length > 0) result[table] = rows;
        }

        return { params: query, changes: result };
    }

    private isValidTable(table: string): boolean {
        const allowed = ['users', 'products', 'categories', 'tables', 'halls', 'sales', 'sale_items', 'customers', 'shifts', 'kitchens', 'settings'];
        return allowed.includes(table);
    }
}
